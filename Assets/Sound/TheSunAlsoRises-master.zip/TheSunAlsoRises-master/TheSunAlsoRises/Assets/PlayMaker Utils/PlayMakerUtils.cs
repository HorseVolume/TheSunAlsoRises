//	(c) Jean Fabre, 2013 All rights reserved.
//	http://www.fabrejean.net
//  contact: http://www.fabrejean.net/contact.htm
//
// Version Alpha 0.1

// INSTRUCTIONS
// This set of utils is here to help custom action development, and scripts in general that wants to connect and work with PlayMaker API.

public partial class PlayMakerUtils {
	// This is the main file to keep old package happy. Each section of PlayMaker Utils are now in distinct files with partial implementation.
}